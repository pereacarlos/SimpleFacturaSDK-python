from enum import Enum

class MedioPagoEnum(Enum):
    NotSet = "NotSet"
    CH = "CH"
    CF = "CF"
    LT = "LT"
    EF = "EF"
    PE = "PE"
    TC = "TC"
    OT = "OT"