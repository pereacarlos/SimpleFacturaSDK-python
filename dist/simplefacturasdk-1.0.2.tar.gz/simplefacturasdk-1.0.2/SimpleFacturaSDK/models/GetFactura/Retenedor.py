from dataclasses import dataclass

@dataclass
class Retenedor:
    IndAgente: str 
    MntBaseFaena: int 
    MntMargComer: int 
    PrcConsFinal: int 

