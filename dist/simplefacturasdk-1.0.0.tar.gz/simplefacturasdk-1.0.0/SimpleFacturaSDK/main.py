from setuptools import find_packages
print(find_packages())